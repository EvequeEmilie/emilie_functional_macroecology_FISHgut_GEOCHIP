"""macroeco_distributions: Common macroecological distributions"""

from .macroeco_distributions import *
